import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='rgreddy',
    application_name='app',
    app_uid='VcCPH40XbMzW8RgS6d',
    org_uid='6b9af93b-db2c-4538-b35e-b3ead2a54415',
    deployment_uid='8d59fe70-98fb-42a1-84b6-d08a7912fbf1',
    service_name='backend',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'backend-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
