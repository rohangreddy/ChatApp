from pprint import pprint
import boto3

def put_room(chatId, userKey, members, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', endpoint_url="http://localhost:8000")

    table = dynamodb.Table('Chatrooms')
    response = table.put_item(
        Item={
            'chatId': chatId,
            'userKey': userKey,
            'info': members
        }
    )
    return response

if __name__ == '__main__':
    chatroom_resp = put_room('Room1', 'key1', ['user2', 'user3', 'user4'])
    print("Put room succeeded")
    pprint(chatroom_resp, sort_dicts=False)
