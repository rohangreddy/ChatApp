import boto3

def add_entry(instance, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', endpoint_url = "http://localhost:8000")
    
    table = dynamodb.Table(instance.table)
    response = table.put_item(Item=vars(instance))
    print(f"Added new entry to {instance.table}: {instance.id}")

def get_entry(table, id, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', endpoint_url = "http://localhost:8000")
    
    table = dynamodb.Table(table)
    response = table.get_item(Key={'id': id})
    try:
        return response['Item']
    except KeyError:
        print("Instance with given id does not exist")
        return None