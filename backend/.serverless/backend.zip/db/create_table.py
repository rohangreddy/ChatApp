import boto3

def create_chatroom_table(dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1', endpoint_url="http://localhost:8000")


    table = dynamodb.create_table(
        TableName='Chatrooms',
        KeySchema=[
            {
                'AttributeName': 'chatId',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'userKey',
                'KeyType': 'RANGE'
            }
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'userKey-chatId-index',
                'KeySchema': [
                    {
                        'AttributeName': 'userKey',
                        'KeyType': 'HASH'
                    },
                    {
                        'AttributeName': 'chatId',
                        'KeyType': 'RANGE'
                    }
                ],
                'Projection': {
                    'ProjectionType': 'ALL'
                },
                'ProvisionedThroughput': {
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'chatId',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'userKey',
                'AttributeType': 'S'
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 1,
            'WriteCapacityUnits': 1
        }
    )
    return table

if __name__ == '__main__':
    chatroom_table = create_chatroom_table()
    print("Table status:", chatroom_table.table_status)
